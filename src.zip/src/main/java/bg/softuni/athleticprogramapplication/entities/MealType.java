package bg.softuni.athleticprogramapplication.entities;

public enum MealType {
    MAIN_DISH, DESERT, DRINK
}
