package bg.softuni.athleticprogramapplication.entities;

public enum ProgramGoal {
    LOSE_FAT, GAIN_MUSCLE, FORM
}
