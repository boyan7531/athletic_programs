package bg.softuni.athleticprogramapplication;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AthleticProgramApplication {

    public static void main(String[] args) {
        SpringApplication.run(AthleticProgramApplication.class, args);
    }

}
