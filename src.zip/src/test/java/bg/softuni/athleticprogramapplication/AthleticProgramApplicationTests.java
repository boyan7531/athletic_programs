package bg.softuni.athleticprogramapplication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AthleticProgramApplicationTests {

    @Test
    void contextLoads() {
    }

}
